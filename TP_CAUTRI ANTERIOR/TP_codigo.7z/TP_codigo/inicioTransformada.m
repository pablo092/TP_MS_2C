clc
clear

[audio,Fs] = audioread('Audio-TPMatSup.wav');

%Es estereo -> separo los canales
canal1 = audio(1:end,1);
canal2 = audio(1:end,2);

%Grafico x[n]
subplot(4,4,1)
plot(Fs,canal1);
subplot(4,4,2)
plot(Fs,canal2);

%Transformada z
T1 = transZ(canal1);
T2 = transZ(canal2);

%Se calcula el valor de la transformada z para cada punto->x[z] 
canal1Trans=obtenerValores(T1,length(canal1));
canal2Trans=obtenerValores(T2,length(canal2));

%Grafico x[z]
subplot(4,4,3)
plot(Fs,canal1Trans);
subplot(4,4,4)
plot(Fs,canal2Trans);

%Se aplica el filtro (devuelve x[z]*h[z])
F1=filtrar2(T1);
F2=filtrar2(T2);

%Se calcula el valor de y[z] para cada punto
canal1Filtrado=obtenerValores(F1,length(canal1));
canal2Filtrado=obtenerValores(F2,length(canal2));

%Grafico y[z]
subplot(4,4,5)
plot(Fs,canal1Filtrado);
subplot(4,4,6)
plot(Fs,canal2Filtrado);

%Antitransformada z: 
AT1=iztrans(F1);
AT2=iztrans(F2);

%Se calculan los valores de y[n]
resultadoCanal1=obtenerValores(AT1,length(canal1));
resultadoCanal2=obtenerValores(AT2,length(canal2));

%Grafico y[n]
subplot(4,4,7);
plot(Fs,resultadoCanal1);
subplot(4,4,8);
plot(Fs,resultadoCanal2);
