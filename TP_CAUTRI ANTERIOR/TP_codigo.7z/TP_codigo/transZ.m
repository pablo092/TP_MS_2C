function F = transZ(x)
    syms z
    [~, t2] = size(x);
    longitud = length(x);
    n = (0:longitud-1);
    if t2 == 1
        n = transpose(n);
    end
    %Se aplica definici�n de transformada z
    F = sum(x.*(z.^-n));
end

